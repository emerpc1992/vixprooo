"""
vixpro_auth.py
----------------------------------------------------------------------
VIXPRO-BOT - Modulo unico de autenticacion OAuth2 + PKCE con Deriv
(API nueva: developers.deriv.com / api.derivws.com), integrado con
tkinter.

Este archivo combina:
  1. La logica de bajo nivel (login via servidor Bolt, polling,
     refresh de token, llamadas autenticadas a la API).
  2. Un mixin de tkinter listo para usar (VixproAuthMixin) que podes
     agregar a la clase de tu GUI sin reescribir nada.

El client_secret de Deriv NUNCA esta en este archivo ni en el bot:
vive solo en el servidor (Bolt), como variable de entorno. Este
modulo solo habla HTTP con tu servidor.

Requiere:
    pip install requests

----------------------------------------------------------------------
USO RAPIDO
----------------------------------------------------------------------
import tkinter as tk
from vixpro_auth import VixproAuthMixin

class MiApp(VixproAuthMixin, tk.Tk):
    def __init__(self):
        super().__init__()
        self.init_vixpro_auth()  # crea estado interno (tokens, timers)

        btn = tk.Button(self, text="Conectar con Deriv",
                         command=self.conectar_con_oauth)
        btn.pack()

        self.lbl_estado_oauth = tk.Label(self, text="No conectado")
        self.lbl_estado_oauth.pack()

    def on_oauth_conectado(self, token_data):
        # Se llama automaticamente cuando el login (o un refresh)
        # termina con exito. Sobreescribi este metodo en tu clase
        # para conectar tu WebSocket/REST con self.access_token.
        print("Token listo:", self.access_token)

if __name__ == "__main__":
    MiApp().mainloop()
----------------------------------------------------------------------
"""

import threading
import time
import webbrowser

import requests

# ----------------------------------------------------------------------
# CONFIGURACION
# ----------------------------------------------------------------------
SERVER_URL = "https://CAMBIAR-ESTO.onrender.com"  # tu URL real de Render, sin barra final
DERIV_APP_ID = "33AAhTttdb54bShIXnfqZ"  # tu client_id (publico, no secreto)

POLL_INTERVAL_SEG = 2
POLL_TIMEOUT_SEG = 180
HTTP_TIMEOUT_SEG = 15

API_BASE_URL = "https://api.derivws.com"  # API REST nueva de Deriv


# ----------------------------------------------------------------------
# SECCION 1: funciones de bajo nivel (sin tkinter, reutilizables)
# ----------------------------------------------------------------------
def _iniciar_flujo_en_servidor() -> dict:
    resp = requests.get(f"{SERVER_URL}/auth/start.json", timeout=HTTP_TIMEOUT_SEG)
    resp.raise_for_status()
    return resp.json()


def _consultar_token(state: str) -> dict:
    resp = requests.get(
        f"{SERVER_URL}/api/token",
        params={"state": state},
        timeout=HTTP_TIMEOUT_SEG,
    )
    resp.raise_for_status()
    return resp.json()


def iniciar_login_oauth(on_success, on_error, on_status=None):
    """
    Lanza el flujo OAuth2+PKCE completo (via servidor Bolt) en un
    hilo de fondo, para no bloquear el mainloop de tkinter.

    on_success(token_data: dict) recibe, entre otros campos:
        access_token, refresh_token, expires_in, token_type

    IMPORTANTE: estos callbacks corren en un hilo secundario. El
    mixin de abajo ya se encarga de volver al hilo principal con
    root.after(), no hace falta que lo hagas vos si usas el mixin.
    """

    def _avisar_estado(msg):
        if on_status:
            on_status(msg)

    def _worker():
        try:
            _avisar_estado("Solicitando flujo de autorizacion al servidor...")
            datos_inicio = _iniciar_flujo_en_servidor()
            state = datos_inicio.get("state")
            auth_url = datos_inicio.get("auth_url")

            if not state or not auth_url:
                on_error("El servidor no devolvio state/auth_url validos.")
                return

            _avisar_estado("Abriendo navegador para autorizar en Deriv...")
            webbrowser.open(auth_url)

            tiempo_inicio = time.time()
            while time.time() - tiempo_inicio < POLL_TIMEOUT_SEG:
                time.sleep(POLL_INTERVAL_SEG)
                resultado = _consultar_token(state)
                status = resultado.get("status")

                if status == "done":
                    token_data = resultado.get("token", {})
                    if not token_data.get("access_token"):
                        on_error("El servidor devolvio 'done' pero sin access_token.")
                        return
                    _avisar_estado("Token recibido correctamente.")
                    on_success(token_data)
                    return

                if status == "error":
                    on_error(f"Error reportado por el servidor: {resultado.get('error')}")
                    return

                if status == "not_found":
                    on_error("La sesion expiro o no existe en el servidor. Reintenta.")
                    return

                _avisar_estado("Esperando que completes el login en Deriv...")

            on_error("Tiempo de espera agotado esperando la autorizacion del usuario.")

        except requests.HTTPError as e:
            on_error(f"Error HTTP hablando con el servidor: {e}")
        except requests.ConnectionError:
            on_error("No se pudo conectar al servidor. Verifica que este desplegado y la URL sea correcta.")
        except Exception as e:
            on_error(f"Error inesperado en login OAuth: {e}")

    threading.Thread(target=_worker, daemon=True).start()


def refrescar_token(refresh_token: str) -> dict:
    """
    Llama al servidor para renovar el access_token usando el
    refresh_token (la API nueva da tokens de corta duracion,
    tipicamente ~3600s).
    """
    resp = requests.post(
        f"{SERVER_URL}/api/refresh",
        json={"refresh_token": refresh_token},
        timeout=HTTP_TIMEOUT_SEG,
    )
    resp.raise_for_status()
    data = resp.json()
    if data.get("status") != "done":
        raise RuntimeError(f"Refresh fallido: {data.get('error')}")
    return data["token"]


def _headers_autenticados(access_token: str) -> dict:
    """La API nueva de Deriv exige estos DOS headers en cada llamada."""
    return {
        "Deriv-App-ID": DERIV_APP_ID,
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }


def get_accounts(access_token: str) -> dict:
    """Ejemplo: GET /trading/v1/options/accounts"""
    resp = requests.get(
        f"{API_BASE_URL}/trading/v1/options/accounts",
        headers=_headers_autenticados(access_token),
        timeout=HTTP_TIMEOUT_SEG,
    )
    resp.raise_for_status()
    return resp.json()


def crear_cuenta_demo(access_token: str, currency: str = "USD") -> dict:
    """Ejemplo: POST /trading/v1/options/accounts (cuenta demo)"""
    resp = requests.post(
        f"{API_BASE_URL}/trading/v1/options/accounts",
        headers=_headers_autenticados(access_token),
        json={"currency": currency, "group": "row", "account_type": "demo"},
        timeout=HTTP_TIMEOUT_SEG,
    )
    resp.raise_for_status()
    return resp.json()


# ----------------------------------------------------------------------
# SECCION 2: Mixin de tkinter listo para usar
# ----------------------------------------------------------------------
class VixproAuthMixin:
    """
    Mixin para agregar autenticacion Deriv a cualquier clase de
    tkinter (tk.Tk, tk.Toplevel, o tu clase de GUI principal).

    Requiere que la clase que lo usa tenga un atributo `self` que
    sea, o contenga, un widget tkinter raiz con `.after()` y
    `.after_cancel()` -- en general eso ya lo cumple tk.Tk/tk.Toplevel.
    Si tu clase NO hereda de un widget tkinter (por ejemplo, es una
    clase de control que tiene self.root como referencia al root real),
    sobreescribi `_tk_root()` para devolver ese root.

    Metodos que podes/debes usar desde tu GUI:
        self.init_vixpro_auth()       -> llamar una vez en __init__
        self.conectar_con_oauth()     -> conectar al boton "Conectar"
        self.access_token             -> token actual (o None)
        self.refresh_token            -> refresh token actual (o None)

    Hooks que podes sobreescribir en tu clase (opcionales):
        self.on_oauth_status(mensaje)     -> progreso del login
        self.on_oauth_conectado(token)     -> login o refresh exitoso
        self.on_oauth_error(mensaje)       -> fallo en login o refresh
    """

    def init_vixpro_auth(self):
        self.access_token = None
        self.refresh_token = None
        self._vixpro_refresh_timer_id = None

    def _tk_root(self):
        """Devuelve el widget con .after()/.after_cancel(). Sobreescribir
        si tu clase no es ella misma un widget tkinter."""
        return self

    # ------------------------------------------------------------
    # Login inicial
    # ------------------------------------------------------------
    def conectar_con_oauth(self):
        """Conectar esto al boton 'Conectar con Deriv' de tu UI."""
        self.on_oauth_status("Abriendo navegador para autorizar...")

        def on_success(token_data):
            self._tk_root().after(0, lambda: self._vixpro_oauth_exitoso(token_data))

        def on_error(mensaje):
            self._tk_root().after(0, lambda: self._vixpro_oauth_fallido(mensaje))

        def on_status(mensaje):
            self._tk_root().after(0, lambda: self.on_oauth_status(mensaje))

        iniciar_login_oauth(on_success, on_error, on_status)

    def _vixpro_oauth_exitoso(self, token_data):
        """Corre en el hilo principal de tkinter (via after)."""
        self.access_token = token_data.get("access_token")
        self.refresh_token = token_data.get("refresh_token")
        expires_in = token_data.get("expires_in", 3600)

        if not self.access_token:
            self._vixpro_oauth_fallido("Respuesta sin access_token.")
            return

        self._programar_refresh(expires_in)
        self.on_oauth_conectado(token_data)

    def _vixpro_oauth_fallido(self, mensaje):
        self.on_oauth_error(mensaje)

    # ------------------------------------------------------------
    # Refresh automatico
    # ------------------------------------------------------------
    def _programar_refresh(self, expires_in_seg):
        """Programa la renovacion automatica del token, 60s antes
        de que venza (margen de seguridad)."""
        root = self._tk_root()
        if self._vixpro_refresh_timer_id:
            root.after_cancel(self._vixpro_refresh_timer_id)

        margen_seg = 60
        espera_ms = max((expires_in_seg - margen_seg), 10) * 1000
        self._vixpro_refresh_timer_id = root.after(espera_ms, self._ejecutar_refresh)

    def _ejecutar_refresh(self):
        """Disparado por after(); el HTTP en si va en un hilo aparte
        para no bloquear la UI."""
        if not self.refresh_token:
            return

        def _worker():
            try:
                nuevo_token = refrescar_token(self.refresh_token)
                self._tk_root().after(0, lambda: self._vixpro_oauth_exitoso(nuevo_token))
            except Exception as e:
                mensaje = f"Fallo al renovar token: {e}. Reconecta manualmente."
                self._tk_root().after(0, lambda: self.on_oauth_error(mensaje))

        threading.Thread(target=_worker, daemon=True).start()

    # ------------------------------------------------------------
    # Hooks por defecto -- sobreescribir en tu clase de GUI
    # ------------------------------------------------------------
    def on_oauth_status(self, mensaje):
        """Por defecto solo imprime. Sobreescribir para actualizar
        un Label de tu UI, ej:
            self.lbl_estado_oauth.config(text=mensaje)
        """
        print(f"[VIXPRO-AUTH] {mensaje}")

    def on_oauth_conectado(self, token_data):
        """Por defecto solo imprime. Sobreescribir para arrancar tu
        conexion WebSocket/REST con self.access_token, actualizar
        labels, habilitar botones, etc."""
        print(f"[VIXPRO-AUTH] Conectado. access_token={token_data.get('access_token')[:12]}...")

    def on_oauth_error(self, mensaje):
        """Por defecto solo imprime. Sobreescribir para mostrar el
        error en tu UI."""
        print(f"[VIXPRO-AUTH] ERROR: {mensaje}")


# ----------------------------------------------------------------------
# Prueba standalone: python vixpro_auth.py
# Crea una ventanita minima para probar el flujo completo end-to-end.
# ----------------------------------------------------------------------
if __name__ == "__main__":
    import tkinter as tk

    class AppPrueba(VixproAuthMixin, tk.Tk):
        def __init__(self):
            super().__init__()
            self.title("VIXPRO-BOT - Prueba de OAuth")
            self.geometry("420x160")
            self.init_vixpro_auth()

            self.btn_conectar = tk.Button(
                self, text="Conectar con Deriv", command=self.conectar_con_oauth
            )
            self.btn_conectar.pack(pady=20)

            self.lbl_estado_oauth = tk.Label(self, text="No conectado")
            self.lbl_estado_oauth.pack(pady=10)

        def on_oauth_status(self, mensaje):
            self.lbl_estado_oauth.config(text=mensaje)

        def on_oauth_conectado(self, token_data):
            self.lbl_estado_oauth.config(text="Conectado ✓")
            self.btn_conectar.config(state="normal")
            print("\n[OK] Token completo recibido:")
            print(token_data)

        def on_oauth_error(self, mensaje):
            self.lbl_estado_oauth.config(text=f"Error: {mensaje}")
            self.btn_conectar.config(state="normal")

    AppPrueba().mainloop()
